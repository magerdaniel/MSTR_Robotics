class saufen():
    def bier(self):
        print("Biertrinken is wichtig")
