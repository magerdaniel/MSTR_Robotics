# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mstr_robotics']

package_data = \
{'': ['*']}

install_requires = \
['requires-python>=3.7']

setup_kwargs = {
    'name': 'mstr-robotics-magerdaniel',
    'version': '0.0.1',
    'description': 'Demo Python scripts to automating MicroStrategy devOps processes',
    'long_description': 'None',
    'author': 'Daniel Mager',
    'author_email': 'danielmager@gmx.de',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
}


setup(**setup_kwargs)
